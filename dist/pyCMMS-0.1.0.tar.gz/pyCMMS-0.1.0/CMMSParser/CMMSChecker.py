from CMMSParser import CMMSParser

# get a list of CMMS YAML entries

# then run through each YAML entry doing the checker for errors

# if error found report back as logging.error(message)

# produce summary message (when run, how many found, how many passed ok, how many with errors)

def review_cmms_content():

    print 'hello world'