__author__ = "Graham A Parton"
__date__ = "17 Oct 2018"
__copyright__ = "Copyright 2018 United Kingdom Research and Innovation"
__license__ = "${license}"
__contact__ = "graham.parton@stfc.ac.uk"
__version__ = "0.1.0"

#from .CMMSParser import CMMSParser